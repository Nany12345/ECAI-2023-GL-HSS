function r2hv = R2HV(data,W,ref)
    r2hv = 0;
    M = size(data,2);
    for i=1:size(W,1)
        wi = W(i,:);
        r2hv = r2hv+max(min(abs(ref-data)./wi,[],2))^M;
    end
    r2hv = r2hv/size(W,1);
end