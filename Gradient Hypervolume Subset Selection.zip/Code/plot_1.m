clc; clear;
obj = [8,10];
alpha = 1000;
proDisp = {'Linear','Concave','Convex','I-Linear','I-Concave','I-Convex'};
pro = {'linear_triangular','concave_triangular','convex_triangular', ...
    'linear_invertedtriangular','concave_invertedtriangular','convex_invertedtriangular'};
selNum = 100;
numSol2 = 5000;
p = [3,2,4,3,4,2;3,2,4,3,4,2];
ylim = {[25.608,25.620],[25.34,25.42],[25.6280,25.6290],[0.244,0.252],[0.0976,0.0988],[1.38,1.50]; ...
    [57.64,57.66],[57.34,57.44],[57.6645,57.6651],[0.077,0.081],[0.028,0.0285],[0.75,0.85]};
x = {[10,100,1000,10000,100000],[10,100,1000,10000],[10,100,1000,10000,100000],[10,100,1000,10000],[10,100,1000,10000],[10,100,1000]; ...
    [10,100,1000,10000,100000,1000000],[10,100,1000,10000,100000],[10,100,1000,10000,100000,1000000],[10,100,1000,10000],[10,100,1000,10000,100000],[10,100,1000]};
for objInd = 1:2
    M = obj(objInd);
    H = getH(selNum,M);
    r = 1+1/H;
    for proInd = 1:6
        data = load(sprintf('./Data/PF/data_set_%s_M%d_1000000',pro{proInd},M)).data_set;
        ref = ones(1,M)*r;
        j = 100;
        [hvDL4_GA100,rtDL4_GA100] = load_DL4(ref,M,proDisp{proInd},selNum,alpha);
        [hvDL4_TGA,rtDL4_TGA] = load_DL4_TGA(ref,M,proDisp{proInd},selNum,alpha,numSol2);
        [hvLGI,rtLGI] = load_LGI(ref,M,proDisp{proInd},selNum);
        %% Plot Figure
        f = figure('Position',[200,200,550,450]);
        hold on;
        fs = 21;
        lw = 1.5; ms = 20;
        plot(rtLGI,hvLGI,'s','MarkerFaceColor',0.5*ones(1,3),'MarkerSize',ms,'MarkerEdgeColor','k','LineWidth',lw);
        plot(rtDL4_GA100(1),hvDL4_GA100(1),'s','MarkerFaceColor','r','MarkerSize',ms,'MarkerEdgeColor','k','LineWidth',lw);
        plot(rtDL4_TGA(1),hvDL4_TGA(1),'s','MarkerFaceColor','y','MarkerSize',ms,'MarkerEdgeColor','k','LineWidth',lw);
        plot(rtDL4_TGA,hvDL4_TGA,'-o','MarkerFaceColor','g','MarkerSize',ms/2,'MarkerEdgeColor','k','Color','k','LineWidth',lw);
        ax = gca;
        ax.XScale = 'log';
        ax.XLim = [10,max(x{objInd,proInd})];
        ax.XTick = x{objInd,proInd};
        if proInd==1 && objInd==1
            ax.YTick = 25.608:0.002:25.620;
        elseif objInd==1 && proInd==6
            ax.YLim = [1.38-0.00000001,1.50];
            ax.YTick = 1.38:0.02:1.50;
        elseif objInd==2 && proInd==4
            ax.YLim = [0.077,0.081];
            ax.YTick = 0.077:0.001:0.081;
        elseif objInd==2 && proInd==3
            ax.YLim = [57.6645,57.6651];
            ax.YTick = 57.6645:0.0001:57.6651;
        end
        ax.FontName = 'Times New Roman';
        ax.FontSize = fs;
        xlabel('Computation time (s)');
        ylabel('Hypervolume');
        ax.XGrid = 'on';
        yTick = get(gca,'yTick');
        yTickLabel = arrayfun(@(x) sprintf(['%.',num2str(p(objInd,proInd)),'f'],x), yTick,'uniformoutput',false);
        set(gca, 'YTickLabel', yTickLabel);
        set(gca,'LineWidth', 2);
        box off;
        ax2 = axes('Position',get(gca,'Position'),...
               'XAxisLocation','top',...
               'YAxisLocation','right',...
               'Color','none',...
               'XColor','k','YColor','k');
        set(ax2,'YTick', []);
        set(ax2,'XTick', []);
        set(ax2,'LineWidth', 2);
        % output high-quality vector diagram
        set(gcf, 'renderer', 'painters');
        title([proDisp{proInd},' ({\it m} = ',num2str(M),')'], ...
            'FontWeight','normal','Interpreter','latex','FontSize',fs, ...
            'FontName','Times New Roman');
        saveas(f,sprintf('./Figure/Overall/M%d_%s.emf',M,proDisp{proInd}));
        close all;
    end
end
function[hv,rt] = load_DL4_TGA(ref,M,proDispName,selNum,alpha,numSol2)
    fileName = sprintf('./Result/TGAHSS_M%d_%s_selNum=%d_numSol2=%d.mat',M,proDispName,selNum,numSol2);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS4_TGA_M%d_%s_selNum=%d_alpha=%d_numSol2=%d.mat',M,proDispName,selNum,alpha,numSol2);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS4_TGA_M%d_%s_selNum=%d_alpha=%d_numSol2=%d.mat',M,proDispName,selNum,alpha,numSol2);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_GA(ref,M,proDispName,selNum,j)
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    dataSel = load(fileName).dataSel;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = stk_dominatedhv(dataSel,ref);
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL_Random(ref,M,proDispName,selNum)
    fileName = sprintf('./Result/DLHSS3_Random_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_DLHSS3_Random_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL_Approx_GA(ref,M,proDispName,selNum,j)
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS3_Approx_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS3_Approx_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL4(ref,M,proDispName,selNum,alpha)
    j = 100;
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL(ref,M,proDispName,selNum,j)
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS3_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS3_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_LGI(ref,M,proDispName,selNum)
    fileName = sprintf('./Result/LGIHSS_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    dataSel = load(fileName).dataSel;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_LGIHSS_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = stk_dominatedhv(dataSel,ref);
        save(fileName,'hv');
    end
end

function v = nvector(m)
    for i=1:size(m,2)
        mt = m;
        mt(:,i) = [];
        v(i) = (-1)^(i-1)*det(mt);
    end
end
function H = getH(N,M)
    H = 1;
    while nchoosek(H+M,M-1) <= N
        H = H + 1;
    end
end
function h = hvc(data,i,ref)
    s = data(i,:);
    data(i,:) = [];
    datap = max(data,s);
    h = prod(ref-datap)-stk_dominatedhv(datap,ref);
end