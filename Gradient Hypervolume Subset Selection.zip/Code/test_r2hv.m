a = UniformPoint(40,5);
hvt = zeros(1,30);
hva = zeros(1,30);
W = UniformVector(8855,5);
for i=1:40
    ai = (41-i)*a;
    hvt(i) = stk_dominatedhv(ai,41*ones(1,5));
    hva(i) = R2HV(ai,W,41*ones(1,5));
end
plot(hvt,hva,'o');

ref = 2*ones(1,5);
hva1 = R2HV(a,W,ref);
hva2 = R2HV(-1*a,W,-1*ref);