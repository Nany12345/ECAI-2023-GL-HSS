clc; clear;
obj = [8,10];
alphaSet = [1,10,100,1000,10000,100000,1000000];
proDisp = {'Linear','Concave','Convex','I-Linear','I-Concave','I-Convex'};
pro = {'linear_triangular','concave_triangular','convex_triangular', ...
    'linear_invertedtriangular','concave_invertedtriangular','convex_invertedtriangular'};
selNum = 100;
numSol2 = 5000;
fs = 18;
hv = zeros(12,length(alphaSet));
for objInd = 1:2
    M = obj(objInd);
    H = getH(selNum,M);
    r = 1+1/H;
    for proInd = 1:6
        data = load(sprintf('./Data/PF/data_set_%s_M%d_1000000',pro{proInd},M)).data_set;
        ref = ones(1,M)*r;
        j = 100;
        for alphaInd = 1:length(alphaSet)
            alpha = alphaSet(alphaInd);
            hva = load_DL4_TGA(ref,M,proDisp{proInd},selNum,alpha,numSol2);
            hv((objInd-1)*6+proInd,alphaInd) = hva(end);
        end
    end
end
hvn = (hv-min(hv,[],2))./(max(hv,[],2)-min(hv,[],2));
setInd = [1,4,7,10;2,5,8,11;3,6,9,12];
shapeName = {'Linear','Concave','Convex'};
subname = {'Linear ($m=8$)','I-Linear ($m=8$)','Linear ($m=10$)','I-Linear ($m=10$)';...
        'Concave ($m=8$)','I-Concave ($m=8$)','Concave ($m=10$)','I-Concave ($m=10$)'; ...
        'Convex ($m=8$)','I-Convex ($m=8$)','Convex ($m=10$)','I-Convex ($m=10$)'};
for i = 1:size(setInd,1)
    % normalize hv
    %% Plot Figure
    f = figure('Position',[200,200,850,180]);
    hold on;
    lw = 1; ms = 8;
    plot(alphaSet,hvn(setInd(i,1),:),'-o','LineWidth',lw,'MarkerSize',ms, ...
        'MarkerEdgeColor','k','MarkerFaceColor','r','Color',0.5*ones(1,3));
    hold on;
    plot(alphaSet,hvn(setInd(i,2),:),'-o','LineWidth',lw,'MarkerSize',ms, ...
        'MarkerEdgeColor','k','MarkerFaceColor','g','Color',0.5*ones(1,3));
    hold on;
    plot(alphaSet,hvn(setInd(i,3),:),'-o','LineWidth',lw,'MarkerSize',ms, ...
        'MarkerEdgeColor','k','MarkerFaceColor','b','Color',0.5*ones(1,3));
    hold on;
    plot(alphaSet,hvn(setInd(i,4),:),'-o','LineWidth',lw,'MarkerSize',ms, ...
        'MarkerEdgeColor','k','MarkerFaceColor','y','Color',0.5*ones(1,3));
    hold on;
    ax = gca;
    ax.XScale = 'log';
    ax.XLim = [1,1000000];
    ax.YLim = [0,1];
    ax.XTick = alphaSet;
    legend(subname{i,:},'Interpreter','latex','Location','eastoutside','Box','off');
    ax.XMinorTick = 'off';
    ax.FontName = 'Times New Roman';
    ax.FontSize = fs;
    xlabel('Neighbor candidate set size: \alpha');
    ylabel('NHV');
    ax.YGrid = 'off';
    ax.XMinorGrid = 'off';
    ax.YTick = 0:0.5:1;
    ax.YTickLabel = {'0.0','0.5','1.0'};
    ax.YMinorTick = 'off';
    set(gca,'LineWidth', 2);
    box off;
    ax2 = axes('Position',get(gca,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');
    set(ax2,'YTick', []);
    set(ax2,'XTick', []);
    set(ax2,'LineWidth', 2);
    % output high-quality vector diagram
    set(gcf, 'renderer', 'painters');
%     title(['{\it m} = ',num2str(M)], ...
%         'FontWeight','normal','Interpreter','latex','FontSize',fs, ...
%         'FontName','Times New Roman');
    saveas(f,sprintf('./Figure/alpha/%s.emf',shapeName{i}));
    close all;
end
function[hv,rt] = load_DL4_TGA(ref,M,proDispName,selNum,alpha,numSol2)
    fileName = sprintf('./Result/TGAHSS_M%d_%s_selNum=%d_numSol2=%d.mat',M,proDispName,selNum,numSol2);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS4_TGA_M%d_%s_selNum=%d_alpha=%d_numSol2=%d.mat',M,proDispName,selNum,alpha,numSol2);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS4_TGA_M%d_%s_selNum=%d_alpha=%d_numSol2=%d.mat',M,proDispName,selNum,alpha,numSol2);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_GA(ref,M,proDispName,selNum,j)
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    dataSel = load(fileName).dataSel;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = stk_dominatedhv(dataSel,ref);
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL_Random(ref,M,proDispName,selNum)
    fileName = sprintf('./Result/DLHSS3_Random_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_DLHSS3_Random_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL_Approx_GA(ref,M,proDispName,selNum,j)
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS3_Approx_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS3_Approx_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL4(ref,M,proDispName,selNum,alpha)
    j = 100;
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL(ref,M,proDispName,selNum,j)
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS3_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS3_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_LGI(ref,M,proDispName,selNum)
    fileName = sprintf('./Result/LGIHSS_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    dataSel = load(fileName).dataSel;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_LGIHSS_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = stk_dominatedhv(dataSel,ref);
        save(fileName,'hv');
    end
end

function v = nvector(m)
    for i=1:size(m,2)
        mt = m;
        mt(:,i) = [];
        v(i) = (-1)^(i-1)*det(mt);
    end
end
function H = getH(N,M)
    H = 1;
    while nchoosek(H+M,M-1) <= N
        H = H + 1;
    end
end
function h = hvc(data,i,ref)
    s = data(i,:);
    data(i,:) = [];
    datap = max(data,s);
    h = prod(ref-datap)-stk_dominatedhv(datap,ref);
end