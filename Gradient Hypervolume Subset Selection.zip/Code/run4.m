clc; clear;
obj = [8,10];
proDisp = {'Linear','Concave','Convex','I-Linear','I-Concave','I-Convex'};
pro = {'linear_triangular','concave_triangular','convex_triangular', ...
    'linear_invertedtriangular','concave_invertedtriangular','convex_invertedtriangular'};
alphaSet = [1,10,100,1000,10000];
selNum = 100;
for objInd = 1:2
    M = obj(objInd);
    H = getH(selNum,M);
    r = 1+1/H;
    for proInd = 1:6
        alpha = 1000;
        data = load(sprintf('./Data/PF/data_set_%s_M%d_1000000',pro{proInd},M)).data_set;
        ref = ones(1,M)*r;
        run_DL4_Random(ref,M,data,selNum,proDisp{proInd},alpha);
    end
end
function run_DL4_Random(ref,M,data,selNum,proDispName,alpha)
    rng(1);
    tic;
    dataSelRand = data(randperm(size(data,1),selNum),:);
    rt_random = toc;
    fprintf('M%d_%s_DL-HSS4-Random\n',M,proDispName)
    fileName = sprintf('./Result/DLHSS4_Random_M%d_%s_selNum=%d_alpha=%d.mat',M,proDispName,selNum,alpha);
    [dataSelSet,runTime] = DLHSS4(data,dataSelRand,selNum,alpha,ref);
    runTime = rt_random+runTime;
    save(fileName,'dataSelSet','runTime');
end
function run_DL4_GA(ref,M,data,selNum,proDispName,alpha)
    j = 100;
    fileNameGA = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileNameGA,'file')
        dataSelGA = load(fileNameGA).dataSel;
    else
        [dataSel,runTime] = GAHSS(data,selNum,j,1,ref);
        save(fileNameGA,'dataSel','runTime');
        dataSelGA = dataSel;
    end
    fprintf('M%d_%s_DL-HSS4-GA%d_alpha=%d\n',M,proDispName,j,alpha);
    fileName = sprintf('./Result/DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    [dataSelSet,runTime] = DLHSS4(data,dataSelGA,selNum,alpha,ref);
    save(fileName,'dataSelSet','runTime');
end
function run_DL4_GA_10(ref,M,data,selNum,proDispName,alpha)
    j = 10;
    fileNameGA = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileNameGA,'file')
        dataSelGA = load(fileNameGA).dataSel;
    else
        [dataSel,runTime] = GAHSS(data,selNum,j,1,ref);
        save(fileNameGA,'dataSel','runTime');
        dataSelGA = dataSel;
    end
    fprintf('M%d_%s_DL-HSS4-GA%d_alpha=%d\n',M,proDispName,j,alpha);
    fileName = sprintf('./Result/DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    [dataSelSet,runTime] = DLHSS4(data,dataSelGA,selNum,alpha,ref);
    save(fileName,'dataSelSet','runTime');
end
function run_DL3_GA(ref,M,data,selNum,proDispName,j)
    fprintf('M%d_%s_GAHSS%d\n',M,proDispName,j)
    fileNameGA = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    if exist(fileNameGA,'file')
        dataSelGA = load(fileNameGA).dataSel;
    else
        [dataSel,runTime] = GAHSS(data,selNum,j,1,ref);
        save(fileNameGA,'dataSel','runTime');
        dataSelGA = dataSel;
    end
    fprintf('M%d_%s_DL-HSS3-GA%d\n',M,proDispName,j)
    fileName = sprintf('./Result/DLHSS3_GA%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    [dataSelSet,runTime] = DLHSS3(data,dataSelGA,selNum,ref);
    save(fileName,'dataSelSet','runTime');
end

function v = nvector(m)
    for i=1:size(m,2)
        mt = m;
        mt(:,i) = [];
        v(i) = (-1)^(i-1)*det(mt);
    end
end
function H = getH(N,M)
    H = 1;
    while nchoosek(H+M,M-1) <= N
        H = H + 1;
    end
end
function h = hvc(data,i,ref)
    s = data(i,:);
    data(i,:) = [];
    datap = max(data,s);
    h = prod(ref-datap)-stk_dominatedhv(datap,ref);
end