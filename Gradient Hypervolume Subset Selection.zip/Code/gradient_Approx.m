function g = gradient_Approx(data,ind,M,seed,ref)
    rng(seed);
    s = data(ind,:);
    data(ind,:) = [];
    g = zeros(1,M);
    W = UniformVector(10000,M-1);
    for i=1:M
        lobj = [1:i-1,i+1:M];
        ind = data(:,i)<s(i);
        data_consider = data(ind,:);
        datal = data_consider(:,lobj);
        sl = s(lobj);
        rl = ref(lobj);
        g(i) = -1*R2HVC(datal,sl,W,rl);
    end
end

function r2hvc = R2HVC(data,s,W,ref)
    temp = min(abs(s-ref)./W,[],2)';
    for i=1:size(data,1)
        temp1 = max((data(i,:)-s)./W,[],2)';
        temp = min([temp;temp1],[],1);
    end
    r2hvc = sum(temp);
end