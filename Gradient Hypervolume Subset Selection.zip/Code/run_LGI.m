obj = [8,10];
proDisp = {'Linear','Concave','Convex','I-Linear','I-Concave','I-Convex'};
pro = {'linear_triangular','concave_triangular','convex_triangular', ...
    'linear_invertedtriangular','concave_invertedtriangular','convex_invertedtriangular'};
selNum = 100;
for objInd = 2
    M = obj(objInd);
    H = getH(selNum,M);
    r = 1+1/H;
    parfor proInd = 1:6
        data = load(sprintf('./Data/PF/data_set_%s_M%d_1000000',pro{proInd},M)).data_set;
        ref = ones(1,M)*r;
        fprintf('M%d_%s_LGI-HSS\n',M,proDisp{proInd})
        fileName = sprintf('./Result/LGIHSS_M%d_%s_selNum=%d.mat',M,proDisp{proInd},selNum);
        if exist(fileName,'file')
            dataSelLGI = load(fileName).dataSel;
            rtLGI = load(fileName).runTime;
        else
            [dataSel,runTime] = LGIHSS(data,selNum,ref,1000000);
            parsave(fileName,dataSel,runTime);
            dataSelLGI = dataSel; rtLGI = runTime;
        end
    end
end
function parsave(fileName,dataSel,runTime)
    save(fileName,'dataSel','runTime');
end
function [dataSelSet,runTime] = DLHSS2(data,dataSel,selNum,refSel,proInd)
    tic;
    runTime = [0];
    M = size(data,2);
    dataSelSet = zeros(selNum,M,2);
    dataSelSet(:,:,1) = dataSel;
    gen = 2;
    while true
        isC = false(1,selNum);
        for j=1:selNum
            hvC = stk_dominatedhv(dataSel,refSel);
            while true
                g = gradient(dataSel,j,M,refSel);
                % project the gradient to the PF plane
                if proInd==1 || proInd==4
                    n = (-1/sqrt(M))*ones(1,M);
                elseif proInd==2 || proInd==5
                    n = -1*dataSel(j,:);
                    n = (1/norm(n))*n;
                elseif proInd==3 || proInd==6
                    n = dataSel(j,:)-1;
                    n = (1/norm(n))*n;
                end
                cos_angle = sum(g.*n)./(norm(g)*norm(n));
                gpn = norm(g)*cos_angle;
                gp = n*gpn;
                gf = g-gp;
                % Calculate the angle of all candidate solutions along the
                % direction
                dist = pdist2(data,dataSel(j,:));
                [~,indd] = mink(dist,20);
                cos_angle = sum((data(indd,:)-dataSel(j,:)).*gf,2)./(sqrt(sum((data(indd,:)-dataSel(j,:)).^2,2)).*norm(gf));
                [~,inda] = max(cos_angle);
                hvN = stk_dominatedhv([dataSel([1:j-1,j+1:end],:);data(indd(inda),:)],refSel);
                if hvN>hvC
                    isC(j) = true;
                    % disp([gen,j]);
                    dataSel(j,:) = data(indd(inda),:);
                    hvC = hvN;
                else
                    break;
                end
            end
        end
        dataSelSet(:,:,gen) = dataSel;
        runTime = [runTime,runTime(end)+toc];
        tic;
        gen = gen+1;
        if sum(isC)==0
            break
        end
    end
end

function v = nvector(m)
    for i=1:size(m,2)
        mt = m;
        mt(:,i) = [];
        v(i) = (-1)^(i-1)*det(mt);
    end
end
function H = getH(N,M)
    H = 1;
    while nchoosek(H+M,M-1) <= N
        H = H + 1;
    end
end
function h = hvc(data,i,ref)
    s = data(i,:);
    data(i,:) = [];
    datap = max(data,s);
    h = prod(ref-datap)-stk_dominatedhv(datap,ref);
end