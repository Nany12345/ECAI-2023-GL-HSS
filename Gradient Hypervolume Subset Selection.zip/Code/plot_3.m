clc; clear;
obj = [8,10];
alphaSet = [1,10,100,1000,10000];
proDisp = {'Linear','Concave','Convex','I-Linear','I-Concave','I-Convex'};
pro = {'linear_triangular','concave_triangular','convex_triangular', ...
    'linear_invertedtriangular','concave_invertedtriangular','convex_invertedtriangular'};
selNum = 100;
numSol2 = 5000;
fs = 23;
p = [3,2,4,3,3,2;2,2,4,3,3,2];
x = {0:50:250,0:50:250,0:50:250,0:50:250,0:50:250,0:50:250; ...
    0:200:800,0:200:800,0:200:800,0:100:400,0:100:300,0:100:400};
for objInd = 2
    M = obj(objInd);
    H = getH(selNum,M);
    r = 1+1/H;
    for proInd = 1
        data = load(sprintf('./Data/PF/data_set_%s_M%d_1000000',pro{proInd},M)).data_set;
        ref = ones(1,M)*r;
        j = 100;
        alpha = 1000;
        [hvDL4_GA100,rtDL4_GA100] = load_DL4(ref,M,proDisp{proInd},selNum,alpha);
        [hvDL4_GA10,rtDL4_GA10] = load_DL4_GA10(ref,M,proDisp{proInd},selNum,alpha);
        [hvDL4_TGA,rtDL4_TGA] = load_DL4_TGA(ref,M,proDisp{proInd},selNum,alpha,numSol2);
        [hvDL4_Random,rtDL4_Random] = load_DL4_Random(ref,M,proDisp{proInd},selNum,alpha);
        %% Plot Figure
        f = figure('Position',[200,200,550,450]);
        hold on;
        fs = 21;
        lw = 1.5; ms = 20;
        plot(rtDL4_TGA,hvDL4_TGA,'-o','MarkerFaceColor','g','MarkerSize',ms/2,'MarkerEdgeColor','k','Color','k','LineWidth',lw);
        plot(rtDL4_GA100,hvDL4_GA100,'-o','MarkerFaceColor','r','MarkerSize',ms/2,'MarkerEdgeColor','k','Color','k','LineWidth',lw);
        plot(rtDL4_GA10,hvDL4_GA10,'-o','MarkerFaceColor','b','MarkerSize',ms/2,'MarkerEdgeColor','k','Color','k','LineWidth',lw);
        plot(rtDL4_Random(2:end),hvDL4_Random(2:end),'-o','MarkerFaceColor','y','MarkerSize',ms/2,'MarkerEdgeColor','k','Color','k','LineWidth',lw);
        ax = gca;
        ax.XTick = x{objInd,proInd};
        ax.XLim = [0,max(x{objInd,proInd})];
        if objInd==2 && proInd==6
            ax.YLim = [0.72,0.86];
            ax.YTick = 0.72:0.02:0.86;
        elseif objInd==1 && proInd==6
            ax.YLim = [1.34,1.50];
            ax.YTick = 1.34:0.02:1.50;
        elseif objInd==2 && proInd==1
            ax.YLim = [57.45,57.7];
            ax.YTick = 57.45:0.05:57.7;
        end
        ax.FontName = 'Times New Roman';
        ax.FontSize = fs;
        xlabel('Computation time (s)');
        ylabel('Hypervolume');
        ax.XGrid = 'on';
        % legend({'TGAHSS','GAHSS-100','GAHSS-10','Random'},'Location','southeast');
        yTick = get(gca,'yTick');
        yTickLabel = arrayfun(@(x) sprintf(['%.',num2str(p(objInd,proInd)),'f'],x), yTick,'uniformoutput',false);
        set(gca, 'YTickLabel', yTickLabel);
        set(gca,'LineWidth', 2);
        box off;
        ax2 = axes('Position',get(gca,'Position'),...
               'XAxisLocation','top',...
               'YAxisLocation','right',...
               'Color','none',...
               'XColor','k','YColor','k');
        set(ax2,'YTick', []);
        set(ax2,'XTick', []);
        set(ax2,'LineWidth', 2);
        % output high-quality vector diagram
        set(gcf, 'renderer', 'painters');
        title([proDisp{proInd},' ({\it m} = ',num2str(M),')'], ...
            'FontWeight','normal','Interpreter','latex','FontSize',fs, ...
            'FontName','Times New Roman');
        saveas(f,sprintf('./Figure/Initialization/M%d_%s.emf',M,proDisp{proInd}));
        close all;
    end
end
function[hv,rt] = load_DL4_TGA(ref,M,proDispName,selNum,alpha,numSol2)
    fileName = sprintf('./Result/TGAHSS_M%d_%s_selNum=%d_numSol2=%d.mat',M,proDispName,selNum,numSol2);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS4_TGA_M%d_%s_selNum=%d_alpha=%d_numSol2=%d.mat',M,proDispName,selNum,alpha,numSol2);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS4_TGA_M%d_%s_selNum=%d_alpha=%d_numSol2=%d.mat',M,proDispName,selNum,alpha,numSol2);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL4_Random(ref,M,proDispName,selNum,alpha)
    fileName = sprintf('./Result/DLHSS4_Random_M%d_%s_selNum=%d_alpha=%d.mat',M,proDispName,selNum,alpha);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_DLHSS4_Random_M%d_%s_selNum=%d_alpha=%d.mat',M,proDispName,selNum,alpha);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL4(ref,M,proDispName,selNum,alpha)
    j = 100;
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_DL4_GA10(ref,M,proDispName,selNum,alpha)
    j = 10;
    fileName = sprintf('./Result/GAHSS%d_M%d_%s_selNum=%d.mat',j,M,proDispName,selNum);
    rtGA = load(fileName).runTime;
    fileName = sprintf('./Result/DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    dataSelSet = load(fileName).dataSelSet;
    rt = load(fileName).runTime;
    rt = rtGA+rt;
    fileName = sprintf('./Result/HV_DLHSS4_GA%d_M%d_%s_selNum=%d_alpha=%d.mat',j,M,proDispName,selNum,alpha);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = zeros(1,length(rt));
        for i=1:length(rt)
            hv(i) = stk_dominatedhv(dataSelSet(:,:,i),ref);
        end
        save(fileName,'hv');
    end
end
function[hv,rt] = load_LGI(ref,M,proDispName,selNum)
    fileName = sprintf('./Result/LGIHSS_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    dataSel = load(fileName).dataSel;
    rt = load(fileName).runTime;
    fileName = sprintf('./Result/HV_LGIHSS_M%d_%s_selNum=%d.mat',M,proDispName,selNum);
    if exist(fileName,'file')
        hv = load(fileName).hv;
    else
        hv = stk_dominatedhv(dataSel,ref);
        save(fileName,'hv');
    end
end

function v = nvector(m)
    for i=1:size(m,2)
        mt = m;
        mt(:,i) = [];
        v(i) = (-1)^(i-1)*det(mt);
    end
end
function H = getH(N,M)
    H = 1;
    while nchoosek(H+M,M-1) <= N
        H = H + 1;
    end
end
function h = hvc(data,i,ref)
    s = data(i,:);
    data(i,:) = [];
    datap = max(data,s);
    h = prod(ref-datap)-stk_dominatedhv(datap,ref);
end