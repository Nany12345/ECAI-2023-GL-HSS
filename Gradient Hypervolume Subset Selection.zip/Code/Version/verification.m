data = [0,1;0.25,0.75;0.75,0.25;1,0];
hold on;
plot([0,1],[1,0],'Color',[177,233,239]./255);
axes('Color','None');
hold on;
plot(data(:,1),data(:,2),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','k','MarkerSize',30,'LineWidth',5);
plot(0.7,0.3,'.','MarkerFaceColor','r','MarkerEdgeColor','r','MarkerSize',30,'LineWidth',5);
g = -1*[0.45,0.05];
quiver(0.7, 0.3, g(1), g(2), 'LineWidth', 2,'Color','r')

% data = [1,0,0;0,1,0;0,0,1; ...
%     2/3,1/3,0;1/3,2/3,0; ...
%     0,1/3,2/3;0,2/3,1/3; ...
%     2/3,0,1/3;1/3,0,2/3];
% fsurf(@(x,y) 1-x-y)
% axis([0,1,0,1,0,1]);
% view(135,45);
% axes('Color','None');
% hold on;
% plot3(data(:,1),data(:,2),data(:,3),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','k','MarkerSize',30,'LineWidth',5);
% axis([0,1,0,1,0,1]);
% view(135,45);
% s = [0.5,0.5,0];
% r = [1.1,1.1,1.1];
% plot3(s(1),s(2),s(3),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','r','MarkerSize',30,'LineWidth',5);
% g = [0,0,0];
% for i=1:3
%     ind = find(data(:,i)<s(i));
%     datac = data(ind,:);
%     datacl = datac(:,[1:i-1,i+1:3]);
%     rl = r([1:i-1,i+1:3]);
%     sl = s([1:i-1,i+1:3]);
%     dataclp = max(datacl,sl);
%     g(i) = -1*(prod(rl-sl)-stk_dominatedhv(dataclp(NDSort(dataclp,1)==1,:),rl));
% end
% quiver3(s(1),s(2),s(3), g(1), g(2),g(3), 'LineWidth', 2,'Color','r')
% point_on_plane = [0,0,1]; % a point on the plane
% normal_to_plane = [1,1,1]; % the normal vector to the plane
% 
% % Define the point to project
% point_to_project = s+g;
% 
% % Calculate the projection
% d = dot(point_to_project - point_on_plane, normal_to_plane) / norm(normal_to_plane)^2;
% pp = point_to_project - d * normal_to_plane;
% plot3(pp(1),pp(2),pp(3),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','g','MarkerSize',30,'LineWidth',5);

