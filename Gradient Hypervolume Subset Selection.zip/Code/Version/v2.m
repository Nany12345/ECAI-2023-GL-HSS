rng(1);
datao = load('Data_M3_WFGConcaveTriangle_1').data;
datao = datao(randperm(size(datao,1),5000),:);
data = LGIHSS(datao,100,[1.1,1.1,1.1],20000);
data(sum(data>0.4,2)==3,:) = [];
fsurf(@(x,y) sqrt(1-x^2-y^2),'FaceColor',[177,233,239]./255,'EdgeColor',[177,233,239]./255);
axis([0,1,0,1,0,1]);
view(135,45);
axes('Color','None');
hold on;
plot3(data(:,1),data(:,2),data(:,3),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','k','MarkerSize',30,'LineWidth',5);
axis([0,1,0,1,0,1]);
view(135,45);
s = [0.6,0.4,sqrt(1-0.36-0.16)];
plot3(s(1),s(2),s(3),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','r','MarkerSize',30,'LineWidth',5);
hv = zeros(1,100);
for i = 1:100
    hv(i) = stk_dominatedhv([data;s],[1.1,1.1,1.1]);
    g = gradient([data;s],size(data,1)+1,3,[1.1,1.1,1.1]);
    n = -1*s;
    cos_angle = sum(g.*n)./(norm(g)*norm(n));
    gpn = norm(g)*cos_angle;
    gp = n*gpn;
    gf = g-gp;
    gf = gf./sqrt(sum(gf.^2,2));
    s1 = s+0.002*gf;
    plot3(s1(1),s1(2),s1(3),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','y','MarkerSize',7,'LineWidth',0.1);
    s = s1;
end
figure;
plot(hv);

function g = diff(obj,dobj,M)
    g1 = dobj(1);
    g2 = -2*obj(1)/(2*obj(M));
    g = g1/g2;
end