rng(1);
M = 8;
H = getH(50,M);
r = 1+1/H;
refEva = ones(1,M)*r;
data = load('Data_M8_WFGConcaveTriangle_1').data;
refSel = max(data,[],1)*r;
% [dataSel,runTime] = LGIHSS(data,50,refSel,20000);
% save('./Result/LGIHSS_M3_WFGConcaveTriangle_1','dataSel','runTime');
% [dataSel,runTime] = GAHSS(data,50,1,refSel);
% save('./Result/GAHSS_M3_WFGConcaveTriangle_1_1','dataSel','runTime');
hv = zeros(1,500);
rt = zeros(1,500);
tic;
for i = 1:100
    isC = false(1,50);
    for j=1:50
        hvC = stk_dominatedhv(dataSel,refSel);
        while true
            g = gradient(dataSel,j,M,refSel);
            % project the gradient to the PF plane
            n = -1*dataSel(j,:);
            cos_angle = sum(g.*n)./(norm(g)*norm(n));
            gpn = norm(g)*cos_angle;
            gp = n*gpn;
            gf = g-gp;
            % Calculate the angle of all candidate solutions along the
            % direction
            cos_angle = sum((data-dataSel(j,:)).*gf,2)./(sqrt(sum((data-dataSel(j,:)).^2,2)).*norm(gf));
            [~,inda] = maxk(cos_angle,80);
            dist = pdist2(data(inda,:),dataSel(j,:));
            [~,indd] = min(dist);
            hvN = stk_dominatedhv([dataSel([1:j-1,j+1:end],:);data(inda(indd),:)],refSel);
            if hvN>hvC
                isC(j) = true;
                disp([i,j]);
                dataSel(j,:) = data(inda(indd),:);
                hvC = hvN;
            else
                break;
            end
        end
        rt((i-1)*50+j) = toc;
        hv((i-1)*50+j) = stk_dominatedhv(dataSel,refSel);
        tic;
    end
    if sum(isC)==0
        break
    end
end
plot(hv(hv>0));

function H = getH(N,M)
    H = 1;
    while nchoosek(H+M,M-1) <= N
        H = H + 1;
    end
end
function h = hvc(data,i,ref)
    s = data(i,:);
    data(i,:) = [];
    datap = max(data,s);
    h = prod(ref-datap)-stk_dominatedhv(datap,ref);
end