rng(1);
data = load('Data_M3_WFGConcaveTriangle_1').data;
datas = LGIHSS(data,20,[1.1,1.1,1.1],20000);

ind = 8;
s = datas(ind,:);
datap = datas;
datap(ind,:) = [];

% plot
fsurf(@(x,y) sqrt(1-x^2-y^2),'FaceColor',[177,233,239]./255,'EdgeColor',[177,233,239]./255);
axis([0,1,0,1,0,1]);
view(135,45);
axes('Color','None');
hold on;
plot3(datap(:,1),datap(:,2),datap(:,3),'.','MarkerFaceColor',0.5*ones(1,3),'MarkerEdgeColor','k','MarkerSize',20,'LineWidth',0.5);
plot3(s(:,1),s(:,2),s(:,3),'.','MarkerFaceColor','r','MarkerEdgeColor','r','MarkerSize',20,'LineWidth',0.5);
axis([0,1,0,1,0,1]);
view(135,45);
hv = zeros(1,11);
hv(1) = stk_dominatedhv([datap;s],[1.1,1.1,1.1]);
for i = 1:10
    g = gradient([datap;s],size(datap,1)+1,3,[1.1,1.1,1.1]);
    n = -1*s;
    cos_angle = sum(g.*n)./(norm(g)*norm(n));
    gpn = norm(g)*cos_angle;
    gp = n*gpn;
    gf = g-gp;
    cos_angle = sum((data-s).*gf,2)./(sqrt(sum((data-s).^2,2)).*norm(gf));
    gf = 0.5*gf./sqrt(sum(gf.^2,2));
    % quiver3(s(1),s(2),s(3), gf(1), gf(2),gf(3), 'LineWidth', 2,'Color','r')
    [~,inda] = maxk(cos_angle,20);
    [~,indd] = min(pdist2(data(inda,:),s));
    s = data(inda(indd),:);
    plot3(s(1),s(2),s(3),'.','MarkerFaceColor','g','MarkerEdgeColor','g','MarkerSize',8,'LineWidth',0.5);
    hv(i+1) = stk_dominatedhv([datap;s],[1.1,1.1,1.1]);
end
figure;
plot(hv);