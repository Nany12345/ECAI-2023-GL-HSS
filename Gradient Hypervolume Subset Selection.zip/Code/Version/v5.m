rng(1);
M = 3;
selNum = 50;
H = getH(50,M);
r = 1+1/H;
proDisp = {'Concave','Linear','Convex','I-Concave','I-Linear','I-Convex'};
pro = {'WFGConcaveTriangle','WFGLinearTriangle','WFGConvexTriangle','WFGConcaveInvTriangle','WFGLinearInvTriangle','WFGConvexInvTriangle'};
refEva = ones(1,M)*r;
for proInd = 1:6
    data = load(sprintf('Data_M%d_%s_1',M,pro{proInd})).data;
    refSel = max(data,[],1)*r;
    fileName = sprintf('./Result/LGIHSS_M%d_%s_1.mat',M,pro{proInd});
    if exist(fileName,'file')
        dataSelLGI = load(fileName).dataSel;
        rtLGI = load(fileName).runTime;
    else
        [dataSel,runTime] = LGIHSS(data,selNum,refSel,1000000);
        save(fileName,'dataSel','runTime');
        dataSelLGI = dataSel; rtLGI = runTime;
    end
    fileNameGA = sprintf('./Result/GAHSS_M%d_%s_1_1.mat',M,pro{proInd});
    if exist(fileNameGA,'file')
        dataSelGA = load(fileNameGA).dataSel;
        rtGA = load(fileNameGA).runTime;
    else
        [dataSel,runTime] = GAHSS(data,selNum,1,refSel);
        save(fileNameGA,'dataSel','runTime');
        dataSelGA = dataSel; rtGA = runTime;
    end
%     fileNameDL = sprintf('./Result/DLHSS_M%d_%s_1_1.mat',M,pro{proInd});
%     if exist(fileNameDL,'file')
%         dataSelSetDL = load(fileNameDL).dataSelSet;
%         rtDL = load(fileNameDL).runTime;
%     else
%         [dataSelSet,runTime] = DLHSS(data,dataSelGA,selNum,refSel,proInd);
%         save(fileNameDL,'dataSelSet','runTime');
%         dataSelSetDL = dataSelSet; rtDL = runTime;
%     end
%     fileNameDL2 = sprintf('./Result/DLHSS2_M%d_%s_1_1.mat',M,pro{proInd});
%     if exist(fileNameDL2,'file')
%         dataSelSetDL2 = load(fileNameDL2).dataSelSet;
%         rtDL2 = load(fileNameDL2).runTime;
%     else
%         [dataSelSet,runTime] = DLHSS2(data,dataSelGA,selNum,refSel,proInd);
%         save(fileNameDL2,'dataSelSet','runTime');
%         dataSelSetDL2 = dataSelSet; rtDL2 = runTime;
%     end
    fileNameDLAda = sprintf('./Result/DLHSSAda_M%d_%s_1_1.mat',M,pro{proInd});
    if exist(fileNameDLAda,'file')
        dataSelSetDL2 = load(fileNameDLAda).dataSelSet;
        rtDL2 = load(fileNameDL2).runTime;
    else
        [dataSelSet,runTime] = DLHSSAda(data,dataSelGA,selNum,refSel);
        save(fileNameDL2,'dataSelSet','runTime');
        dataSelSetDLAda = dataSelSet; rtDLAda = runTime;
    end
    rtDL = rtGA+rtDL;
    rtDL2 = rtGA+rtDL2;
    hvLGI = stk_dominatedhv(dataSelLGI,refEva);
    hvGA = stk_dominatedhv(dataSelGA,refEva);
    hvDL = zeros(1,length(rtDL));
    for i=1:length(rtDL)
        hvDL(i) = stk_dominatedhv(dataSelSetDL(:,:,i),refEva);
    end
    hvDL2 = zeros(1,length(rtDL2));
    for i=1:length(rtDL2)
        hvDL2(i) = stk_dominatedhv(dataSelSetDL2(:,:,i),refEva);
    end
    f = figure;
    hold on;
    plot(rtLGI,hvLGI,'s','MarkerFaceColor',0.5*ones(1,3),'MarkerSize',20,'MarkerEdgeColor','k');
    plot(rtGA,hvGA,'o','MarkerFaceColor','g','MarkerSize',20,'MarkerEdgeColor','k');
    plot(rtDL,hvDL,'-o','MarkerFaceColor','r','MarkerSize',10,'MarkerEdgeColor','k','Color','k');
    ax = gca;
    ax.FontSize = 15;
    xlabel('Computation time (s)');
    ylabel('Hypervolume');
    ax.XGrid = 'on';
    legend({'LGI-HSS','GAHSS','DL-HSS'},'Location','southeast');
    set(gca,'LineWidth', 2);
    box off;
    ax2 = axes('Position',get(gca,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');
    set(ax2,'YTick', []);
    set(ax2,'XTick', []);
    set(ax2,'LineWidth', 2);
    % output high-quality vector diagram
    set(gcf, 'renderer', 'painters');
    title([proDisp{proInd},' ({\it m} = ',num2str(M),')'],'FontWeight','normal','Interpreter','latex','FontSize',15);
    saveas(f,sprintf('./Figure/M%d_%s.png',M,proDisp{proInd}));
    close all;
end

function [dataSelSet,runTime] = DLHSS(data,dataSel,selNum,refSel,proInd)
    tic;
    runTime = [0];
    M = size(data,2);
    dataSelSet = zeros(selNum,M,2);
    dataSelSet(:,:,1) = dataSel;
    gen = 2;
    while true
        isC = false(1,selNum);
        for j=1:selNum
            hvC = stk_dominatedhv(dataSel,refSel);
            while true
                g = gradient(dataSel,j,M,refSel);
                % project the gradient to the PF plane
                if proInd==1 || proInd==4
                    n = -1*dataSel(j,:);
                    n = (1/norm(n))*n;
                elseif proInd==2 || proInd==5
                    n = (-1/sqrt(M))*ones(1,M);
                elseif proInd==3 || proInd==6
                    n = dataSel(j,:)-1;
                    n = (1/norm(n))*n;
                end
                cos_angle = sum(g.*n)./(norm(g)*norm(n));
                gpn = norm(g)*cos_angle;
                gp = n*gpn;
                gf = g-gp;
                % Calculate the angle of all candidate solutions along the
                % direction
                cos_angle = sum((data-dataSel(j,:)).*gf,2)./(sqrt(sum((data-dataSel(j,:)).^2,2)).*norm(gf));
                [~,inda] = maxk(cos_angle,20);
                dist = pdist2(data(inda,:),dataSel(j,:));
                [~,indd] = min(dist);
                hvN = stk_dominatedhv([dataSel([1:j-1,j+1:end],:);data(inda(indd),:)],refSel);
                if hvN>hvC
                    isC(j) = true;
                    % disp([gen,j]);
                    dataSel(j,:) = data(inda(indd),:);
                    hvC = hvN;
                else
                    break;
                end
            end
        end
        dataSelSet(:,:,gen) = dataSel;
        runTime = [runTime,runTime(end)+toc];
        tic;
        gen = gen+1;
        if sum(isC)==0
            break
        end
    end
end

function [dataSelSet,runTime] = DLHSS2(data,dataSel,selNum,refSel,proInd)
    tic;
    runTime = [0];
    M = size(data,2);
    dataSelSet = zeros(selNum,M,2);
    dataSelSet(:,:,1) = dataSel;
    gen = 2;
    while true
        isC = false(1,selNum);
        for j=1:selNum
            hvC = stk_dominatedhv(dataSel,refSel);
            while true
                g = gradient(dataSel,j,M,refSel);
                % project the gradient to the PF plane
                if proInd==1 || proInd==4
                    n = -1*dataSel(j,:);
                    n = (1/norm(n))*n;
                elseif proInd==2 || proInd==5
                    n = (-1/sqrt(M))*ones(1,M);
                elseif proInd==3 || proInd==6
                    n = dataSel(j,:)-1;
                    n = (1/norm(n))*n;
                end
                cos_angle = sum(g.*n)./(norm(g)*norm(n));
                gpn = norm(g)*cos_angle;
                gp = n*gpn;
                gf = g-gp;
                % Calculate the angle of all candidate solutions along the
                % direction
                dist = pdist2(data,dataSel(j,:));
                [~,indd] = mink(dist,20);
                cos_angle = sum((data(indd,:)-dataSel(j,:)).*gf,2)./(sqrt(sum((data(indd,:)-dataSel(j,:)).^2,2)).*norm(gf));
                [~,inda] = max(cos_angle);
                hvN = stk_dominatedhv([dataSel([1:j-1,j+1:end],:);data(indd(inda),:)],refSel);
                if hvN>hvC
                    isC(j) = true;
                    % disp([gen,j]);
                    dataSel(j,:) = data(indd(inda),:);
                    hvC = hvN;
                else
                    break;
                end
            end
        end
        dataSelSet(:,:,gen) = dataSel;
        runTime = [runTime,runTime(end)+toc];
        tic;
        gen = gen+1;
        if sum(isC)==0
            break
        end
    end
end

function [dataSelSet,runTime] = DLHSSAda(data,dataSel,selNum,refSel)
    tic;
    runTime = [0];
    M = size(data,2);
    dataSelSet = zeros(selNum,M,2);
    dataSelSet(:,:,1) = dataSel;
    gen = 2;
    while true
        isC = false(1,selNum);
        for j=1:selNum
            hvC = stk_dominatedhv(dataSel,refSel);
            while true
                g = gradient(dataSel,j,M,refSel);
                % Calculate the angle of all candidate solutions along the
                % direction
                dist = pdist2(data,dataSel(j,:));
                [~,indd] = maxk(dist,20);
                % project the gradient to the PF plane;
                near_dirs = data(indd(1:M-1),:)-dataSel(j,:);
                n = nvector(near_dirs);
                n = n./sum(n);
                if n(1)>0, n = -1*n; end
                cos_angle = sum(g.*n)./(norm(g)*norm(n));
                gpn = norm(g)*cos_angle;
                gp = n*gpn;
                gf = g-gp;
                cos_angle = sum((data(indd,:)-dataSel(j,:)).*gf,2)./(sqrt(sum((data(indd,:)-dataSel(j,:)).^2,2)).*norm(gf));
                [~,inda] = max(cos_angle);
                hvN = stk_dominatedhv([dataSel([1:j-1,j+1:end],:);data(indd(inda),:)],refSel);
                if hvN>hvC
                    isC(j) = true;
                    % disp([gen,j]);
                    dataSel(j,:) = data(indd(inda),:);
                    hvC = hvN;
                else
                    break;
                end
            end
        end
        dataSelSet(:,:,gen) = dataSel;
        runTime = [runTime,runTime(end)+toc];
        tic;
        gen = gen+1;
        if sum(isC)==0
            break
        end
    end
end
function v = nvector(m)
    for i=1:size(m,2)
        mt = m;
        mt(:,i) = [];
        v(i) = (-1)^(i-1)*det(mt);
    end
end
function H = getH(N,M)
    H = 1;
    while nchoosek(H+M,M-1) <= N
        H = H + 1;
    end
end
function h = hvc(data,i,ref)
    s = data(i,:);
    data(i,:) = [];
    datap = max(data,s);
    h = prod(ref-datap)-stk_dominatedhv(datap,ref);
end